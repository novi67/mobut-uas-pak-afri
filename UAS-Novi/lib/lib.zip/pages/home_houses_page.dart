import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/api.dart';
import 'house_detail_page.dart';
import 'package:intl/intl.dart';

class HomeHousesPage extends StatefulWidget {
  const HomeHousesPage({super.key});

  @override
  State<HomeHousesPage> createState() => _HomeHousesPageState();
}

class _HomeHousesPageState extends State<HomeHousesPage> {
  List houses = [];
  bool loading = true;
  final searchC = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetch();
  }

  Future<void> fetch([String q = ""]) async {
    setState(() => loading = true);
    try {
      final res = await Api.dio.get("/houses/list.php", queryParameters: {"q": q});
      final data = res.data is String ? jsonDecode(res.data) : res.data;
      setState(() => houses = (data["data"] ?? []) as List);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal memuat data rumah")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String rupiah(num n) => NumberFormat.currency(locale: "id_ID", symbol: "Rp ", decimalDigits: 0).format(n);

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: () => fetch(searchC.text.trim()),
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          TextField(
            controller: searchC,
            decoration: InputDecoration(
              hintText: "Cari rumah (judul/lokasi)...",
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: () => fetch(searchC.text.trim()),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ✅ List Data
          ...houses.map((h) {
            final title = (h["title"] ?? "").toString();
            final loc = (h["location"] ?? "").toString();
            final price = num.tryParse(h["price"].toString()) ?? 0;
            final img = (h["image_url"] ?? "").toString();

            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => HouseDetailPage(id: h["id"].toString())),
                );
              },
              child: Container( // ✅ Container
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.black12),
                ),
                child: Row(
                  children: [
                    // ✅ Image (Network)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.network(
                        img.isEmpty ? "https://picsum.photos/seed/defaulthouse/200/200" : img,
                        width: 90,
                        height: 90,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 90,
                          height: 90,
                          alignment: Alignment.center,
                          color: Colors.black12,
                          child: const Icon(Icons.broken_image),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(loc),
                          const SizedBox(height: 6),
                          Text(rupiah(price), style: const TextStyle(fontWeight: FontWeight.w600)),
                          const SizedBox(height: 8),
                          // ✅ Button
                          OutlinedButton.icon(
                            onPressed: () {
                              // ✅ SnackBar
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("Disimpan ke favorit: $title")),
                              );
                            },
                            icon: const Icon(Icons.favorite_border),
                            label: const Text("Favorit"),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            );
          }),
          if (houses.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text("Data rumah kosong")),
            ),
        ],
      ),
    );
  }
}
