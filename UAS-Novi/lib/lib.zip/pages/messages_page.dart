import 'package:flutter/material.dart';

class MessagesPage extends StatelessWidget {
  const MessagesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton(
        onPressed: () {
          // ✅ SnackBar (pesan)
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Ini contoh pesan (SnackBar) dari menu Pesan")),
          );
        },
        child: const Text("Tampilkan Message"),
      ),
    );
  }
}
