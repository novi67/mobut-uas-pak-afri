import 'package:flutter/material.dart';
import 'home_houses_page.dart';
import 'articles_page.dart';
import 'favorites_page.dart';
import 'messages_page.dart';
import 'profile_page.dart';

class ShellPage extends StatefulWidget {
  const ShellPage({super.key});

  @override
  State<ShellPage> createState() => _ShellPageState();
}

class _ShellPageState extends State<ShellPage> {
  int index = 0;

  final pages = const [
    HomeHousesPage(),   // 1) Katalog
    ArticlesPage(),     // 2) Artikel
    FavoritesPage(),    // 3) Favorit
    MessagesPage(),     // 4) Pesan
    ProfilePage(),      // 5) Profil
  ];

  final titles = const [
    "Katalog Rumah",
    "Artikel",
    "Favorit",
    "Pesan",
    "Profil",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(titles[index])),
      body: pages[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (i) => setState(() => index = i),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_work), label: "Rumah"),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: "Artikel"),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: "Favorit"),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: "Pesan"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
