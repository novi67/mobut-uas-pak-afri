import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/api.dart';

class ArticlesPage extends StatefulWidget {
  const ArticlesPage({super.key});

  @override
  State<ArticlesPage> createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  List articles = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetch();
  }

  Future<void> fetch() async {
    setState(() => loading = true);
    try {
      final res = await Api.dio.get("/articles/list.php");
      final data = res.data is String ? jsonDecode(res.data) : res.data;
      setState(() => articles = (data["data"] ?? []) as List);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal memuat artikel")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: articles.length,
      itemBuilder: (_, i) {
        final a = articles[i];
        final title = (a["title"] ?? "").toString();
        final body = (a["body"] ?? "").toString();
        final img = (a["image_url"] ?? "").toString();

        return Card(
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                img.isEmpty ? "https://picsum.photos/seed/article$i/120/120" : img,
                width: 56,
                height: 56,
                fit: BoxFit.cover,
              ),
            ),
            title: Text(title),
            subtitle: Text(body.length > 80 ? "${body.substring(0, 80)}..." : body),
          ),
        );
      },
    );
  }
}
