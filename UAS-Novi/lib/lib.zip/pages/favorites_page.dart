
import 'package:flutter/material.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Favorit masih demo.\n(Saat ini favorit ditampilkan via SnackBar)"),
    );
  }
}
