import 'package:dio/dio.dart';

class Api {
  static const String baseUrl = "https://novi.bersama.cloud/api-novi"; // ✅ ganti ke https

  static final Dio dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {"Accept": "application/json"},
      followRedirects: true,
      maxRedirects: 5,
      validateStatus: (status) => status != null && status < 500, // ✅ biar 301 tidak dianggap error
    ),
  );
}
