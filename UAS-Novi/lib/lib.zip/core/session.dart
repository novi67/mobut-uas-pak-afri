import 'package:shared_preferences/shared_preferences.dart';

class Session {
  static const _kToken = "token";
  static const _kName = "name";
  static const _kEmail = "email";

  static Future<void> saveLogin({
    required String token,
    required String name,
    required String email,
  }) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kToken, token);
    await sp.setString(_kName, name);
    await sp.setString(_kEmail, email);
  }

  static Future<void> clear() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove(_kToken);
    await sp.remove(_kName);
    await sp.remove(_kEmail);
  }

  static Future<String?> token() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getString(_kToken);
  }

  static Future<Map<String, String?>> user() async {
    final sp = await SharedPreferences.getInstance();
    return {
      "name": sp.getString(_kName),
      "email": sp.getString(_kEmail),
    };
  }
}
